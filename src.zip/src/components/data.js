const data = [
    {
        id: 1,
        question: "Who is the first black president of America",
        answers: [
            {
                text: "Goodluck Johnathan",
                correct: false
            },
            {
                text: "Barrack Obama",
                correct: true
            },
            {
                text: "Gabriel Godspower",
                correct: false
            },
            {
                text: "Muhammadu Buhari",
                correct: false
            },
        ]
    },
    {
        id: 2,
        question: "Rolex is a company that specialize in what type of product?",
        answers: [
            {
                text: "Phone",
                correct: false
            },
            {
                text: "Watches",
                correct: true
            },
            {
                text: "Food",
                correct: false
            },
            {
                text: "Cosmetics",
                correct: false
            },
        ]
    },
    {
        id: 3,
        question: "When did the websute Facebook launched",
        answers: [
            {
                text: "2004",
                correct: true
            },
            {
                text: "2005",
                correct: false
            },
            {
                text: "2006",
                correct: false
            },
            {
                text: "2007",
                correct: false
            },
        ]
    },
    {
        id: 4,
        question: "Which of these is the best software company in Nigeria",
        answers: [
            {
                text: "Facebook",
                correct: false
            },
            {
                text: "Nigeria Coder's Academy",
                correct: false
            },
            {
                text: "Ogtech Network's Ltd",
                correct: true
            },
            {
                text: "Soft Space Ltd",
                correct: false
            },
        ]
    },
    {
        id: 5,
        question: "Who played the character of Harry potter in movie",
        answers: [
            {
                text: "Leonardo Di Caprio",
                correct: false
            },
            {
                text: "Daniel washington",
                correct: false
            },
            {
                text: "Gabriel Godspower",
                correct: false
            },
            {
                text: "Daniel Red Cliff",
                correct: true
            },
        ]
    },
]
export default data;